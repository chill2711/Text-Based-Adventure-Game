﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StarterGame
{
    class GameWorld
    {
        // singleton to have GameWorld accessible globally and have one instance of the game world
        private static GameWorld _instance = null;
        public static GameWorld Instance
        {
            get
            {
                // lazy initializer
                if(_instance == null)
                {
                    _instance = new GameWorld();
                }
                return _instance;
            }
        }

        // private Room object _entrance
        private Room _entrance;
        // getter and setter for Entrance
        public Room Entrance { get { return _entrance; } }

        // private Room object _exit
        private Room _exit;
        // getter and setter for Exit
        public Room Exit { get { return _exit; } }

        private Room _transportroom;
        public Room TransportRoom { get { return _transportroom; } }

        // private Room object _questRoomStart
        private Room _questRoomStart;
        // getter and setter for QuestRoomStart
        public Room QuestRoomStart { get { return _questRoomStart; } }

        // if i would like to change game world
        //private Dictionary<Room, WorldEvent> worldChanges;

        public static List<Room> rooms = new List<Room>();

        // since private constructor only one instance can be created and can only be created here
        private GameWorld()
        {
            //worldChanges = new Dictionary<Room, WorldEvent>();
            // creating world
            CreateWorld();
            // adding an observer that will receive this notification
            NotificationCenter.Instance.AddObserver("PlayerWillExitRoom", PlayerWillExitRoom);
            NotificationCenter.Instance.AddObserver("PlayerDidExitRoom", PlayerDidExitRoom);
            NotificationCenter.Instance.AddObserver("PlayerBeginsQuest", PlayerBeginsQuest);
            NotificationCenter.Instance.AddObserver("PlayerFoundKey", PlayerFoundKey);
            NotificationCenter.Instance.AddObserver("PlayerCompletedQuest", PlayerCompletedQuest);
            NotificationCenter.Instance.AddObserver("PlayerWins", PlayerWins);

        }

        // notification method that prints notification
        public void PlayerWillExitRoom(Notification notification)
        {
            // casting to make player object
            Player player = (Player)notification.Object;
            if (player.CurrentRoom == _exit)
            {
                player.OutputMessage("Player left the exit room");
            }
            else if(player.CurrentRoom == _transportroom)
            {
                //player.CurrentRoom = randomRoom();
                Door door = Door.connectRooms(_transportroom, randomRoom(), "north", "south");
            }
            else
            {
                player.OutputMessage("Player will exit "+ player.CurrentRoom.Tag);
            }
        }

        
        public void PlayerDidExitRoom(Notification notification)
        {
            Player player = (Player)notification.Object;
            WorldEvent wc = null;
            //worldChanges.TryGetValue(player.CurrentRoom, out wc);
            if(wc != null)
            {
                wc.Execute();
            }
        }

        // quest system for user to find key with notifications
        // challenge task
        public void PlayerBeginsQuest(Notification notification)
        {
            Player player = (Player)notification.Object;
            if (player.CurrentRoom == QuestRoomStart && player.hasDoorKey() == false)
            {
                player.OutputMessage("You have started your quest.\n The door to the north is locked. Find the door key, add it to your inventory, and return here to unlock the door and complete the quest.");
            }
        }

        // notification telling player they found the door key
        public void PlayerFoundKey(Notification notification)
        {
            Player player = (Player)notification.Object;
            if (player.hasDoorKey() == true)
            {
                player.OutputMessage("You have found the door key. Return to the master closet to complete your quest.");
            }
        }

        // notification telling player they completed the quest
        public void PlayerCompletedQuest(Notification notification)
        {
            Player player = (Player)notification.Object;
            if (player.CurrentRoom == QuestRoomStart && player.hasDoorKey() == true)
            {
                player.OutputMessage("You have completed your quest!\n The door to the north is now unlocked.");
            }
        }

        // notification telling player they have solved the case
        public void PlayerWins(Notification notification)
        {
            Player player = (Player)notification.Object;
            if (player.CurrentRoom == Exit && player.hasConfession() == true)
            {
                player.OutputMessage("You have solved the case and found the killer! \nTurns out Jane Smith was the killer after all. \nType 'quit' to end the game or continue to explore for more clues.");
            }
        }

        // creating the world
        private void CreateWorld()
        {
            // creating a room named outsideMansion
            Room outsideMansion = new Room("outside the Charlie Baldwin mansion. It is amazing how only one person is living here in this huge place.\nThis is where our investigation begins.");
            
            // adding room to list of rooms for transport room
            rooms.Add(outsideMansion);

            // creating a room named mansionEntrance
            Room mansionEntrance = new Room("in the mansion entrance. You notice there seems to be no signs of forced entry.");
            // adding room to list of rooms for transport room
            rooms.Add(mansionEntrance);

            // creating a room named office
            Room office = new Room("in the office. You notice there is an open laptop, a TV, and what appears to be unfinished breakfast from the morning");
            // adding room to list of rooms for transport room
            rooms.Add(office);

            // creating a room named kitchen
            Room kitchen = new Room("in the kitchen. While looking around the kitchen, you notice a couple things are off. The first thing that catches your eye is the refrigerator seems to not be closed all the way. Also, there is something off about the counter");
            // adding room to list of rooms for transport room
            rooms.Add(kitchen);

            // creating a room named diningRoom
            Room diningRoom = new Room("in the dining room. There doesn't appear to be any evidence here.");
            // adding room to list of rooms for transport room
            rooms.Add(diningRoom);

            // creating a room named eastWingHallway
            Room eastWingHallway = new Room("in the East Wing Hallway. This hallway connects to the Office, the Kitchen, and the Dining Room");
            // adding room to list of rooms for transport room
            rooms.Add(eastWingHallway);

            // creating a room named southWingHallway
            Room southWingHallway = new Room("in the South Wing Hallway. This hallway connects to the Master Bedroom, the Guest Bedroom, and the Back Porch");
            // adding room to list of rooms for transport room
            rooms.Add(southWingHallway);

            // creating a room named masterBedroom
            Room masterBedroom = new Room("in the Master Bedroom. You notice something is off about the bedside tables. Also, this is where you have your first interaction\nwith this suspect. She introduces herself as Ms. Jane Smith and Charlie’s girlfriend. \nYou can listen to what his girlfriend has to say");
            // adding room to list of rooms for transport room
            rooms.Add(masterBedroom);

            // creating a room named masterBathroom
            Room masterBathroom = new Room("in the Master Bathroom. Here, you notice there is a bottle of pills");
            // adding room to list of rooms for transport room
            rooms.Add(masterBathroom);

            // creating a room named masterClosest
            Room masterCloset = new Room("in the master closet. There appears to be a key that hanging on a key ring.");
            // adding room to list of rooms for transport room
            // do not want to add this room to list because cannot transport here
            //rooms.Add(masterCloset);

            //creating a room named backPorch
            Room backPorch = new Room("on the back porch. You are able to speak with a suspect, Charlie’s chef John. \nJohn appears to be very upset with the loss of Charlie");
            // adding room to list of rooms for transport room
            rooms.Add(backPorch);

            //creating a room named poolHouse
            Room poolHouse = new Room("in the pool house. This seems like a second house. There does not seem to be any evidence here.");
            // adding room to list of rooms for transport room
            rooms.Add(poolHouse);

            //creating a room named poolArea
            Room poolArea = new Room(" in the pool area. Don’t jump in! You’ll freeze this time of year");
            // adding room to list of rooms for transport room
            rooms.Add(poolArea);

            //creating a room named guestBedroom
            Room guestBedroom = new Room("in the guest bedroom. Here you notice something under the bed. You find a box");
            // adding room to list of rooms for transport room
            rooms.Add(guestBedroom);

            //creating a room named west wing hallway
            Room westWingHallway = new Room(" in the West Wing Hallway. This hallway connects to the Movie Room, the Guest Bathroom, and the Collection Room");
            // adding room to list of rooms for transport room
            rooms.Add(westWingHallway);

            //creating a room named movieRoom
            Room movieRoom = new Room("in the Movie Room. In this room, you find a huge collection of movies. Also, you have a suspect here. This suspect is Charlie’s housekeeper Karen White");
            // adding room to list of rooms for transport room
            rooms.Add(movieRoom);

            //creating a room named guestBathroom
            Room guestBathroom = new Room("in the guest bathroom. While looking around, you notice there is a broken window in the guest bathroom");
            // adding room to list of rooms for transport room
            rooms.Add(guestBathroom);

            //creating a room named collectionRoom
            Room collectionRoom = new Room("in the Collection Room. Here, you notice there is a collection of sports memorabilia including autographed jerseys, helmets, \nand more");
            // adding room to list of rooms for transport room
            rooms.Add(collectionRoom);

            //creating a room named safeRoom
            Room safeRoom = new Room("in the safe room. Here, you notice that there is a desk with what appears to be a key on it");
            // adding room to list of rooms for transport room
            rooms.Add(safeRoom);
      

            //creating a room named transportRoom
            // do not want to add this to rooms list because do not want to transport back here
            Room transportRoom = new Room("now in the transport room. This is what Charlie appeared to be working on for the last several years.\nGo back west to be transported to a new random room");

            //creating a trap room named trapRoom
            Room trapRoom = new Room("in the trap room. You will be able to exit if you say the magic word. I hope you have been examining items.");
            // adding room to list of rooms for transport room
            rooms.Add(trapRoom);

            Room vaultRoom = new Room("in the vault. Here you find a confession. Examine the confession to discover the killer, and solve the case.");
            // not adding to room list , we don't want to be able to transport here

            // connecting rooms with doors
            Door door = Door.connectRooms(outsideMansion, mansionEntrance, "north", "south");
            door = Door.connectRooms(mansionEntrance, eastWingHallway, "west", "east");
            door = Door.connectRooms(eastWingHallway, office, "south", "north");
            door = Door.connectRooms(eastWingHallway, kitchen, "west", "east");
            door = Door.connectRooms(eastWingHallway, diningRoom, "north", "south");
            door = Door.connectRooms(diningRoom, kitchen, "north", "south");
            door = Door.connectRooms(mansionEntrance, southWingHallway, "south", "north");
            //this statement has a door closed at start of game
            door.Close();
            // locking a door
            ILocking aLock = new RegularLock();
            door.InstallLock(aLock);
            door.Close();
            door.Lock();
            door = Door.connectRooms(southWingHallway, masterBedroom, "west", "east");
            // this has door from master bedroom to master closet close and locked
            door = Door.connectRooms(masterBedroom, masterCloset, "south", "north");
            door.InstallLock(aLock);
            door.Close();
            door.Lock();
            door = Door.connectRooms(masterBedroom, masterBathroom, "west", "east");
            door = Door.connectRooms(southWingHallway, backPorch, "north", "south");
            door = Door.connectRooms(backPorch, poolHouse, "west", "east");
            door = Door.connectRooms(backPorch, poolArea, "north", "south");
            door = Door.connectRooms(poolArea, poolHouse, "east", "west");
            door = Door.connectRooms(southWingHallway, guestBedroom, "east", "west");
            door = Door.connectRooms(mansionEntrance, westWingHallway, "east", "west");
            door = Door.connectRooms(westWingHallway, movieRoom, "south", "north");
            door = Door.connectRooms(westWingHallway, guestBathroom, "east", "west");
            door = Door.connectRooms(westWingHallway, collectionRoom, "north", "south");
            door = Door.connectRooms(collectionRoom, safeRoom, "north", "south");
            door = Door.connectRooms(safeRoom, transportRoom, "west", "east");
            door = Door.connectRooms(mansionEntrance, southWingHallway, "north", "south");
            door = Door.connectRooms(poolArea, trapRoom, "north", "south");

            door = Door.connectRooms(office, vaultRoom, "south", "north");
            ILocking aLock2 = new RegularLock();
            door.InstallLock(aLock2);
            door.Close();
            door.Lock();

            // setting exit room for end of game
            _exit = vaultRoom;

            // entrance to the world 
            _entrance = outsideMansion;

            // quest Room
            _questRoomStart = masterBedroom;

            //set delegates that implement RoomDelegate interface
            // creates a new RoomDelegate that that is a trap room
            RoomDelegate rd = new TrapRoom();
            //the trapRoom will be this room
            rd.ContainingRoom = trapRoom;
            trapRoom.Delegate = rd;
            
            // delegate for transport room
            RoomDelegate rd2 = new TransportRoom();
            rd2.ContainingRoom = transportRoom;
            transportRoom.Delegate = rd2;


            //items added
            IItem item;
            //ItemInventory chest;
            item = new Item("laptop", 10);
            office.place(item);
            item.Examniation = "You find a document that reveals a contract for Charlie's transporter research. It's a 900 million dollar offer.\nThis could be a motive to the crime.";
            item.canPickup = true;

            item = new Item("note", 1);
            item.Examniation = "Note reads:\nRemember the magic word is magic.";
            mansionEntrance.place(item);
            item.canPickup = true;

            item = new Item("glasses", 2);
            masterBedroom.place(item);
            item.Examniation = "These don't appear to be Charlie's glasses because he had his glasses in his pocket. These seem to belong to someone else.";
            item.canPickup = true;

            // decorator design pattern
            // adding decorator to item
            item = new Item("bottle",2);
            masterBathroom.place(item);
            item.Examniation = "This is a prescription for Jane Smith.";
            IItem decorator = new Item("pills", 1);
            item.AddDecorator(decorator);
            item.canPickup = true;

            //find out what type chest needs to be to store the confession
            // may need to change how we add this item
            // we don't want to know that this item is here until we open the chest
            item = new Item("vaultKey", 3);
            masterCloset.place(item);
            item.Examniation = "Looks like we found the vault key.";
            decorator = new Item("vaultKeyRing", 1);
            item.AddDecorator(decorator);
            item.canPickup = true;

            item = new Item("confession",3);
            item.Examniation = "You have found the confession. The confession reads:\nIf this is ever found, I deserve to be caught. I did it. I killed Charlie. \n-Jane Smith\nBe sure to pickup the confession and add it to your inventory.";
            vaultRoom.place(item);
            item.canPickup = true;

            item = new Item("fridge", 50);
            kitchen.place(item);
            item.Examniation = "In the fridge, you notice two steaks marinating. We can assume it must have been a dinner for two.";
            decorator = new Item("steaks",3);
            item.AddDecorator(decorator);
            item.canPickup = false;

            item = new Item("box", 20);
            guestBedroom.place(item);
            item.Examniation = "After searching through the items in the box, you find a blueprint to some sort of transport research.";
            item.canPickup = false;

            item = new Item("window", 30);
            guestBathroom.place(item);
            item.Examniation = "This window appears to be broken, but the glass is on the outside of the house. Was it broken from the inside to make it look like a break in?";
            item.canPickup = false;

            item = new Item("doorKey", 3);
            safeRoom.place(item);
            item.Examniation = "This appears to be a key to a locked door.";
            decorator = new Item("doorKeyRing", 1);
            item.AddDecorator(decorator);
            item.canPickup = true;

            //adding suspects to the game
            // challenge task adding characters to the game
            // need to come back to figure out how to have characters move around
            ISuspects suspect;
            suspect = new Suspects("Jane");
            masterBedroom.placeSuspect(suspect);
            suspect.message = "Jane is Charlie's girlfriend. Let's see what she has to say.\nJane says: \nI went to the grocery store, and when I got home, I found him. Why would someone want to rob him? I wonder if one of his employees did it.";

            suspect = new Suspects("John");
            backPorch.placeSuspect(suspect);
            suspect.message = "John is Charlie's chef. Let's see what he has to say.\nJohn says: \nCharlie and I were best friends. I've cooked his meals the past 20 years. He has always been very good to me.\nI do not trust his girlfriend however. She is always interested in his money, and I have never been fond of her.";

            suspect = new Suspects("Karen");
            movieRoom.placeSuspect(suspect);
            suspect.message = "Karen is Charlie's housekeeper. Let's see what she has to say.\nKaren says: \nI have been Charlie's housekeeper for the last 12 years. He was always so kind to everyone, but I cannot say the same about his girlfriend Jane.\nYou need to look into her. She's trouble.";

            //this would be if we chose to change the game world
            //_magicRoom = cctparking;
            //WorldChange wc = new WorldChange(schuster, davidson, "west", "east");
            //worldChanges[cctparking] = wc;

        }

        // challenge task for random room transporter
        public static Room randomRoom()
        {
            Room room;
            Random rand = new Random();
            int index = rand.Next(rooms.Count);
            room = rooms[index];
            return room;
        }

        // if we want to have a world event world change in game
        private interface WorldEvent
        {
            void Execute();
        }

        private class WorldChange : WorldEvent
        {
            public Room RoomA { get; set; }
            public Room RoomB {get; set;}
            public string AtoB { get; set; }
            public string BtoA { get; set; }

            public WorldChange(Room roomA, Room roomB, string aToB, string bToA)
            {
                RoomA = roomA;
                RoomB = roomB;
                AtoB = aToB;
                BtoA = bToA;
            }

            public void Execute()
            {
                Door.connectRooms(RoomA, RoomB, AtoB, BtoA);
            }
        }
    }
}

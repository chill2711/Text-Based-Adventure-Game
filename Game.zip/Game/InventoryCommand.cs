﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    public class InventoryCommand : Command
    {
        // inventory Command constructor
        public InventoryCommand() : base()
        {
            this.Name = "inventory";
        }

        // overriding Execute 
        override
        public bool Execute(Player player)
        {
            // if player has another word after inventory
            if (this.HasSecondWord())
            {
                player.OutputMessage("\nI don't know what you mean by " + this.SecondWord);
            }
            else
            {
                // if player does not have a second word 
                player.showInventory();
            }
            return false;
        }
    }
}

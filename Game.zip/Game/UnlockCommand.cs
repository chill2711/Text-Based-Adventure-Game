﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    class UnlockCommand : Command
    {
        // Unlock Command constructor
        public UnlockCommand() : base()
        {
            this.Name = "unlock";
        }

        // overriding Execute 
        override
        public bool Execute(Player player)
        {
            // unlocking the door in this direction or this item
            if (this.HasSecondWord())
            {
                player.Unlock(this.SecondWord);
            }
            else
            {
                // if player does not say what to unlock
                player.OutputMessage("\nUnlock What?");
            }
            return false;
        }
    }
}

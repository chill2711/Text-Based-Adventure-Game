﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    public class Game
    {
        // player object
        Player player;
        // parser
        Parser parser;
        //bool to signal if one is playing the game
        bool playing;

        // game constructor
        public Game()
        {
            // playing set to false
            playing = false;
            // creating a new parser to parse through commands
            parser = new Parser(new CommandWords());
            //this gameworld is only instance of game world
            // singleton now game world is available globally 
            player = new Player(GameWorld.Instance.Entrance);
        }

       
        // play method
        // continues to parse user commands until quit command is input
        public void Play()
        {
            bool finished = false;
            while (!finished)
            {
                Console.WriteLine(">");
                Command command = parser.ParseCommand(Console.ReadLine());
                if(command == null)
                {
                    Console.WriteLine("I don't understand...");
                }
                else
                {
                    finished = command.Execute(player);
                }
             
            }
        }

        // Start method
        // sets playing to true & prints welcome message
        public void Start()
        {
            playing = true;
            player.OutputMessage(Welcome());
            Console.WriteLine(player.CurrentRoom.Description());
        }

        // End method
        // sets playing to false & prints goodbye message
        public void End()
        {
                playing = false;
                player.OutputMessage(Goodbye());
           
        }

        // welcome message string
        public string Welcome()
        {
            return "Welcome to The Mansion Murder Mystery Game!" + "\n" +
                "There has been a murder at the Baldwin Mansion. The owner " +
                "Charlie Baldwin was found dead with a knife in his back.\nYou will be " +
                "the lead investigator and find out who murdered Charlie. \nBe sure to examine " +
                "items for evidence and find clues that could tell you who the murderer is.\n";
        }

        // goodbye message string
        public string Goodbye()
        {
            return "Thank you for playing!";
        }
       
    }
}

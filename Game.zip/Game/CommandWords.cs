﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    public class CommandWords
    {
        // declaring a dictionary of string keys with Command values
        Dictionary<string, Command> commands;
        // array of Commands (add any commands created here)
        private static Command[] commandArray = { new GoCommand(), new QuitCommand(), new OpenCommand(), new SayCommand(), new BackCommand(), new UnlockCommand(), new PickupCommand(), new InventoryCommand(), new DropCommand(), new CloseCommand(), new ExamineCommand(), new ListenCommand()};

        // CommandWords default constructor
        public CommandWords() : this(commandArray)
        {
        }

        // CommandWords constructor 
        public CommandWords(Command[] commandList)
        {
            // creating new dictionary of string keys with Command values
            commands = new Dictionary<string, Command>();
            // loop through commands in commandList
            foreach(Command command in commandList)
            {
                // adding the command to the command dictionary
                commands[command.Name] = command;

            }
            // creating new HelpCommand
            Command help = new HelpCommand(this);
            commands[help.Name] = help;
        }

        // get method to return string of command
        public Command Get(string word)
        {
            Command command = null;
            commands.TryGetValue(word, out command);
            return command;
        }

        // Description returns the commandNames from the key values in Command dictionary
        public string Description()
        {
            string commandNames = "";
            Dictionary<string, Command>.KeyCollection keys = commands.Keys;
            foreach(string commandName in keys)
            {
                commandNames += " " + commandName + ",";
            }
            return commandNames;
        }
    }
}

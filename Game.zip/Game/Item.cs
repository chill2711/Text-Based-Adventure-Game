﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StarterGame
{
    public interface IItem
    {
        public string Name { get; set; }
        public float Weight { get; set; }

        public string Description { get; }

        public void AddDecorator(IItem decorator);

        string Examniation { get; set; }

        bool canPickup { get; set; }

    }
    public class Item : IItem
    {
        private string _name;

        public string Name { get{ return _name; } set { _name = value; } }

        private float _weight;

        public float Weight { get { return _weight + (_decorator!= null?_decorator.Weight:0); } set { _weight = value; } }

        private IItem _decorator;

        public string Examniation { get; set; }

        public bool canPickup { get; set; }


        public Item() : this("No name") { }

        public Item(string name) : this(name, 1.0f) { } 

        public Item(string name, float weight)
        {
            Name = name;
            Weight = weight;
            _decorator = null;
        }

        public string Description
        {
            get
            {
                return "Item Name: " + Name + ", "+ " Weight: " + Weight;

            }
        }

        public void AddDecorator(IItem decorator)
        {
            if(_decorator == null)
            {
                _decorator = decorator;
            }
            else
            {
                _decorator.AddDecorator(decorator);
            }
        }

    }

    // adding and removing item from room and for inventory
    public interface IItemInventory : IItem
    {
        void add(IItem item);
        IItem remove(string itemName);
    }

    // item container
    // container design pattern
    // for player inventory & room floor
    public class ItemInventory : IItemInventory
    {
        private Dictionary<string, IItem> inventory;
        private IItem _decorator;
        public string Name { get; set; }
        private float _weight;
        public float Weight
        {
            get
            {
                float totalWeight = _weight;
                foreach(IItem item in inventory.Values)
                {
                    totalWeight += item.Weight;
                }
                return totalWeight;
            }
            set
            {
                _weight = value;
            }
        }
        public string Examniation { get; set; }

        public bool canPickup { get; set; }

        public ItemInventory() : this("no items in here") { }

        public ItemInventory(string name) : this(name, 1.0f) { }

        public ItemInventory(string name, float weight)
        {
            Name = name;
            Weight = weight;
            inventory = new Dictionary<string, IItem>();
            _decorator = null;
            
        }

        // description to print all items in inventory
        public string Description
        {
            get
            {
                string itemsInInventory = "";
                Dictionary<string, IItem>.KeyCollection keys = inventory.Keys;
                foreach(string itemName in keys)
                {
                    //for debugging
                    //Console.WriteLine("inside ItemInventory description");
                    itemsInInventory += inventory[itemName].Description + "\n";
                }
                return itemsInInventory;

            }


        }

        // adding a decorator
        public void AddDecorator(IItem decorator)
        {
            if (_decorator == null)
            {
                _decorator = decorator;
            }
            else
            {
                _decorator.AddDecorator(decorator);
            }
        }

        // made virtual to be able to override
        public virtual void add(IItem item)
        {
            inventory[item.Name] = item;
        }

        // made virtual to be able to override
        public virtual IItem remove(string itemName)
        {
            IItem item = null;
            inventory.Remove(itemName, out item);
            return item;
        }

    }

}

﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    public class SayCommand : Command
    {
        // Say Command constructor
        public SayCommand() : base()
        {
            this.Name = "say";
        }

        // overriding Execute 
        override
        public bool Execute(Player player)
        {
            // word that will be said
            if (this.HasSecondWord())
            {
                player.Say(this.SecondWord);
            }
            else
            {
                // if player does not say what they are attempting to say
                player.OutputMessage("\nSay What?");
            }
            return false;
        }
    }
}

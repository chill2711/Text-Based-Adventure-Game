﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    // this class will go back to the previous room
    public class BackCommand : Command
    {
        public BackCommand() :base()
        {
            this.Name = "back";
        }

        override
            public bool Execute(Player player)
        {
            player.goBack();
            return false;
        }
    }
}

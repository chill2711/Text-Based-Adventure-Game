﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StarterGame
{
    // Strategy pattern used to implement locks using ILocking
    public interface ILocking
    {
        public bool IsLocked { get; }
        public bool IsUnlocked { get; }

        public void Lock();
        public void Unlock();

        public bool MayOpen { get; }
        public bool MayClose { get; }


    }

    // regular lock implementing ILocking interface
    public class RegularLock : ILocking
    {
        private bool _isLocked;
        public bool IsLocked { get { return _isLocked; } }
        public bool IsUnlocked { get { return !_isLocked; } }

        public bool MayOpen { get { return _isLocked ? false : true; } }
        public bool MayClose { get { return _isLocked ? true : true; } }

        public RegularLock()
        {
            _isLocked = false;
        }

        public void Lock()
        {
            _isLocked = true;
        }
        public void Unlock()
        {
            _isLocked = false;
        }



    }

    // door class implementing ILocking interface
    public class Door : ILocking
    {
        // private variables room1 and room2 that will be connected by door
        private Room _room1;
        private Room _room2;

        // variable to see if door is closed
        private bool _closed;

        // returns true if door is closed
        public bool IsClosed { get { return _closed; } }

        //returns true if door is not closed
        public bool IsOpen { get { return !_closed; } }

        private ILocking _lock;

        //door constructor with rooms that door will connect
        public Door(Room room1, Room room2)
        {
            _room1 = room1;
            _room2 = room2;
            // all doors start open
            _closed = false;
            _lock = null;
        }

        public Room OtherRoom(Room thisRoom)
        {
            if(thisRoom == _room1)
            {
                return _room2;
            }
            else
            {
                return _room1;
            }
        }

        //method to close the door
        public void Close()
        {
            if(_lock != null)
            {
                _closed = _lock.MayClose;
            }
            else
            {
                _closed = true;

            }
        }

        //method to open the door
        public void Open()
        {
            if (_lock != null)
            {
                _closed = !_lock.MayOpen;

            }
            else
            {
                _closed = false;
            }

        }

        // is the door/item locked or unlocked
        public bool IsLocked { get { return _lock != null ? _lock.IsLocked : false; } }
        public bool IsUnlocked { get {return _lock != null ? _lock.IsUnlocked : true; } }

        // locking  a lock
        public void Lock()
        {
            if(_lock != null)
            {
                _lock.Lock();
            }

        }

        // unlocking a lock
        public void Unlock()
        {
            if(_lock != null)
            {
                _lock.Unlock();
            }
        }

        // is the player able to open or close a door
        public bool MayOpen { get { return _lock != null ? _lock.MayOpen : true; } }
        public bool MayClose { get { return _lock != null ? _lock.MayClose : true; } }

        // installing a lock
        public void InstallLock(ILocking newLock)
        {
            _lock = newLock;
        }

        //Helper method that will connect the rooms with the door that is created
        public static Door connectRooms(Room fromRoom, Room toRoom, string fromTo, string toFrom)
        {
            Door door = new Door(fromRoom, toRoom);
            fromRoom.SetExit(toFrom, door);
            toRoom.SetExit(fromTo, door);
            return door;
        }




    }


}

﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    class CloseCommand : Command
    {
        // Close Command constructor
        public CloseCommand() : base()
        {
            this.Name = "close";
        }

        // overriding Execute 
        override
        public bool Execute(Player player)
        {
            // closing this
            if (this.HasSecondWord())
            {
                player.Close(this.SecondWord);
            }
            else
            {
                // if player does not say what to close
                player.OutputMessage("\nOpen What?");
            }
            return false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    public abstract class Command
    {
        // private string _name to hold name value
        private string _name;
        // public string variable that is the same as _name
        // Name getter and setter methods
        public string Name { get { return _name; } set { _name = value; } }

        // private string _secondWord to hold second word value if there is one
        private string _secondWord;
        // SecondWord getter & setter method
        public string SecondWord { get { return _secondWord; } set { _secondWord = value; } }

        // constructor 
        public Command()
        {
            this.Name = "";
            this.SecondWord = null;
        }

        // tests if there is a second word in the command
        public bool HasSecondWord()
        {
            return this.SecondWord != null;
        }

        // execute command
        public abstract bool Execute(Player player);
    }
}

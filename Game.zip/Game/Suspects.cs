﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    // interface for the suspects
    public interface ISuspects
    {
        string Name { set; get; }
        string Description();
        string message { set; get; }
    }

    // suspect class implementing ISuspects interface
    public class Suspects : ISuspects
    {
        public string Name { set; get; }
        public Suspects() : this("Name") { }

        public Suspects(string name)
        {
            Name = name;
        }

        public string Description()
        {
            return Name;
        }
        public string message { set; get; }

    }

    // interface to place and remove suspects
    public interface ISuspectContainer : ISuspects
    {
        void add(ISuspects suspect);
        ISuspects remove(string suspectName);
    }

    // container design pattern for the suspects in each room
    public class SuspectContainter : ISuspectContainer
    {
        private Dictionary<string, ISuspects> suspects;
        public string Name { get; set; }

        public string message { set; get; }


        public SuspectContainter() : this("There are no suspects here.") { }
        public SuspectContainter(string name)
        {
            Name = name;
            suspects = new Dictionary<string, ISuspects>();
        }
       
        // adding a suspect
        public void add(ISuspects suspect)
        {
            suspects[suspect.Name] = suspect;
        }

        // remvoing suspect
        public ISuspects remove(string suspectName)
        {
            ISuspects suspect = null;
            suspects.Remove(suspectName, out suspect);
            return suspect;
        }

        public string Description()
        {
            string suspectNames = "Suspects: ";
            Dictionary<string, ISuspects>.KeyCollection keys = suspects.Keys;
            foreach(string suspectName in keys)
            {
                suspectNames += suspectName;
            }
            return suspectNames;
        }
    }
}

﻿using System;
namespace StarterGame
{
    public class DropCommand : Command
    {
        // Drop Command constructor
        public DropCommand() : base()
        {
            this.Name = "drop";
        }

        // overriding Execute 
        override
        public bool Execute(Player player)
        {
            // which item to drop
            if (this.HasSecondWord())
            {
                player.drop(this.SecondWord);
            }
            else
            {
                // if player does not say what item to drop 
                player.OutputMessage("\nDrop what?");
            }
            return false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StarterGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game();
            game.Start();
            game.Play();
            game.End();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    // using this interface we can create different types of Room delegates
    // for example trap room & magic room & transport room
    public interface RoomDelegate
    {
        Door GetExit(string exitName);
        Room ContainingRoom { set; get; }
        Dictionary<string,Door> Exits { get; set; }
        string Description();
    }

    // creating a TrapRoom implementing Room delegate interface
    public class TrapRoom : RoomDelegate
    {
        private Door _trickDoor;
        public Dictionary<string, Door> Exits { get; set; }

        private string _password;
        public string Password { set; get; }
        public TrapRoom()
        {
            Password = "magic";
            NotificationCenter.Instance.AddObserver("PlayerDidSayWord", PlayerDidSayWord);
        }
        public Door GetExit(string exitName)
        {

            return _trickDoor;
        }
        // will use containing room to assign which room will be trap room
        private Room _containingRoom;
        public Room ContainingRoom
        {
            set
            {
                _containingRoom = value;
                _trickDoor = new Door(_containingRoom, _containingRoom);
                _password = "magic";
                
            }
            get
            {
                return _containingRoom;
            }
        }
        public string Description()
        {
            return "You are now mine.";
        }

        public void PlayerDidSayWord(Notification notification)
        {
            Player player = (Player)notification.Object;
            if(player.CurrentRoom == ContainingRoom)
            {
                Dictionary<string, Object> userInfo = notification.UserInfo;
                string word = (string)userInfo["word"];
                if (word.Equals(_password))
                {
                    player.OutputMessage("You entered the magic word. You can now exit this room to the north. Feel free to come back anytime, now that you said the magic word.");
                    ContainingRoom.Delegate = null;
                }
            }
        }
    }

    // challenge task
    // having a transport room that transports player to a random room
    public class TransportRoom : RoomDelegate
    {
        //private Door door;
        private Room _containingRoom;
        private Door _randomDoor;
        private Dictionary<string, Door> exits;

        public void SetExit(string exitName, Door door)
        {
            exits[exitName] = door;
        }

        public Door GetExit(string exitName)
        {
            return _randomDoor;
        }

        public Room ContainingRoom
        {
            set
            {
                _containingRoom = value;
                _randomDoor = new Door(_containingRoom, GameWorld.randomRoom());

            }
            get
            {
                return _containingRoom;
            }
        }
        public Dictionary<string, Door> Exits { get; set; }
        public string Description()
        {
            return "\n";
        }
    }


    // room class
    public class Room
    {
        private Dictionary<string, Door> exits;
        private string _tag;
        public string Tag
        {
            get
            {
                return _tag;
            }
            set
            {
                _tag = value;
            }
        }

        private RoomDelegate _delegate;
        public RoomDelegate Delegate
        {
            set
            {
                _delegate = value;
                // could probably comment this out
                // does not do anything
                if(_delegate == null)
                {
                   //_delegate.Exits = exits;
                }
            }
        }

        private IItemInventory roomFloor;
        private IItem _item;
        private ISuspects _suspect;
        // room default constructor
        public Room() : this("No Tag")
        {

        }

        // room constructor
        public Room(string tag)
        {
            exits = new Dictionary<string, Door>();
            this.Tag = tag;
            _delegate = null;
            roomFloor = new ItemInventory();
            _item = null;
            _suspect = null;

        }

        // setter method for room exits
        public void SetExit(string exitName, Door door)
        {
            exits[exitName] = door;
        }

        // getter for room exits
        public Door GetExit(string exitName)
        {
            if(_delegate == null)
            {
                Door door = null;
                exits.TryGetValue(exitName, out door);
                return door;
            }
            else
            {
                return _delegate.GetExit(exitName);
            }
        }

        // this method returns the exits for the room when called
        public string GetExits()
        {
            string exitNames = "Exits: ";
            Dictionary<string, Door>.KeyCollection keys = exits.Keys;
            foreach(string exitName in keys)
            {
                exitNames += " " + exitName;
            }
            return exitNames;
        }

        public string Description()
        {
            return (_delegate==null?"":_delegate.Description() +"\n") + "You are " + this.Tag + ".\n *** " + this.GetExits() + "\n" + (_item != null ? "items in room: \n" + _item.Description : "") +"\n" + (_suspect != null ? "Suspects in room: \n" + _suspect.Description() : "");

        }

        // places an item in a room
        public void place(IItem item)
        {
            _item = item;
            //roomFloor.add(_item);
        }

        // removes an item from a room 
        public IItem remove(string itemName)
        {
            IItem itemToReturn = _item;
            _item = null;
            return itemToReturn;

        }

        // places a suspect in a room
        public void placeSuspect(ISuspects suspect)
        {
            _suspect = suspect;
        }

        // removes suspect from a room
        public ISuspects removeSuspect(string suspectName)
        {
            ISuspects suspectReturned = _suspect;
            _suspect = null;
            return suspectReturned;

        }

    }
}

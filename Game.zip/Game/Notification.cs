﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    // notification constructor 
    public class Notification
    {
        // getter and setter for Name
        public String Name { get; set; }

        // getter and setter for Object
        public Object Object { get; set; }

        // dictionary of string keys and Object values
        public Dictionary<String, Object> UserInfo { get; set; }

        public Notification() : this("NotificationName")
        {
        }

        public Notification(String name) : this(name, null)
        {
        }

        public Notification(String name, Object obj) : this(name, obj, null)
        {
        }

        public Notification(String name, Object obj, Dictionary<String, Object> userInfo)
        {
            this.Name = name;
            this.Object = obj;
            this.UserInfo = userInfo;
        }
    }
}

// observer --> subscribes to notification --> [notifcation center] <-- subject sends a notification to notifcation center
// observer will be added to list in the notification center and notifcation sent from subject will be added to the appropriate list

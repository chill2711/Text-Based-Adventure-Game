﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    public class GoCommand : Command
    {
        // Go Command constructor
        public GoCommand() : base() 
        {
            this.Name = "go";
        }

        // overriding Execute 
        override
        public bool Execute(Player player)
        {
            // going to direction of second word
            if (this.HasSecondWord())
            {
                player.WaltTo(this.SecondWord);
            }
            else
            {
                // if player does not say the direction to go 
                player.OutputMessage("\nGo Where?");
            }
            return false;
        }
    }
}

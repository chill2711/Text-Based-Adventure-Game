﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    public class Player
    {
        private Room _currentRoom = null;
        // stack of rooms for the back command
        // will pop the last room from the stack to go back
        private Stack<Room> roomsVisited = new Stack<Room>();
        public Room CurrentRoom
        {
            get
            {
                return _currentRoom;
            }
            set
            {
                _currentRoom = value;
            }
        }

        // player's inventory
        private IItemInventory inventory;

        public Player(Room room)
        {
            roomsVisited = new Stack<Room>();
            _currentRoom = room;
            inventory = new ItemInventory();          
        }

        // player moving around 
        public void WaltTo(string direction)
        {
            Door door = this._currentRoom.GetExit(direction);
            Notification notification;
            if(door != null)
            {
                if (door.IsOpen)
                {
                    Room nextRoom = door.OtherRoom(CurrentRoom);
                    roomsVisited.Push(this.CurrentRoom);
                    notification = new Notification("PlayerWillExitRoom", this);
                    NotificationCenter.Instance.PostNotification(notification);

                    this._currentRoom = nextRoom;
                    notification = new Notification("PlayerDidExitRoom", this);
                    NotificationCenter.Instance.PostNotification(notification);
                    this.OutputMessage("\n" + this._currentRoom.Description());
                }
                else
                {
                    this.OutputMessage("\nThe door in the direction: " + direction + " is closed.");
                    notification = new Notification("PlayerBeginsQuest", this);
                    NotificationCenter.Instance.PostNotification(notification);
                }

            }
        }

        // open command
        public void Open(string direction)
        {
            Door door = this._currentRoom.GetExit(direction);
            if(door != null)
            {
                if (door.IsClosed)
                {
                    door.Open();
                    if (door.IsOpen)
                    {
                        this.OutputMessage("\nThe door on " + direction + " is now open.");
                    }
                    else
                    {
                        this.OutputMessage("\nThe door on " + direction + " is still closed.");
                    }
                }
                else
                {
                    this.OutputMessage("The door on " + direction + " is already open.");
                }
            }
            else
            {
                this.OutputMessage("\nThere is no door on " + direction);
            }

        }

        // close command
        public void Close(string direction)
        {
            Door door = this._currentRoom.GetExit(direction);
            if (door != null)
            {
                if (door.IsOpen)
                {
                    door.Close();
                    if (door.IsClosed)
                    {
                        this.OutputMessage("\nThe door on " + direction + " is now closed.");
                    }
                    else
                    {
                        this.OutputMessage("\nThe door on " + direction + " is still open.");
                    }
                }
                else
                {
                    this.OutputMessage("The door on " + direction + " is already closed.");
                }
            }
            else
            {
                this.OutputMessage("\nThere is no door on " + direction);
            }

        }

        // say command
        public void Say(string word)
        {
            OutputMessage("\n" + word + "\n");
            Dictionary<string, Object> userInfo = new Dictionary<string, object>();
            userInfo["word"] = word;
            Notification notification = new Notification("PlayerDidSayWord", this,userInfo);
            NotificationCenter.Instance.PostNotification(notification);
        }

        // back command
        public void goBack()
        {
            Room nextRoom = this._currentRoom;
            
            if(roomsVisited.Count > 0)
            {
                this._currentRoom = roomsVisited.Pop();
                Notification notification = new Notification("PlayerWillExitRoom", this);
                NotificationCenter.Instance.PostNotification(notification);
                notification = new Notification("PlayerDidExitRoom", this);
                NotificationCenter.Instance.PostNotification(notification);
                this.OutputMessage("\n" + this._currentRoom.Description());
            }
        }
        //output message to display messages to player
        public void OutputMessage(string message)
        {
            Console.WriteLine(message);
        }

        // unlock command
        public void Unlock(string direction)
        {
            Door door = this._currentRoom.GetExit(direction);
            if (door != null)
            {
                if (door.IsLocked && hasDoorKey() == false)
                {
                    this.OutputMessage("You must have the doorKey to unlock this door.");
                }
                // challenge task, player must have doorKey to unlock door
                else if (door.IsLocked && hasDoorKey() == true)
                {
                    door.Unlock();
                    if (door.IsUnlocked)
                    {
                        this.OutputMessage("\nThe door on " + direction + " is now unlocked.");
                        if (hasDoorKey() == true)
                        {
                            // notifying player they completed the quest
                            Notification notification = new Notification("PlayerCompletedQuest", this);
                            NotificationCenter.Instance.PostNotification(notification);
                        }

                    }
                    else
                    {
                        this.OutputMessage("\nThe door on " + direction + " is still locked.");
                    }
                }
                // for unlocking with vault key
                else if (door.IsLocked && hasVaultKey() == true)
                {
                    door.Unlock();
                    if (door.IsUnlocked)
                    {
                        this.OutputMessage("\nThe door on " + direction + " is now unlocked.");
                    }
                    else
                    {
                        this.OutputMessage("\nThe door on " + direction + " is still locked.");
                    }
                }
                else
                {
                    this.OutputMessage("The door on " + direction + " is already unlocked.");
                }
            }
            else
            {
                this.OutputMessage("\nThere is no door on " + direction);
            }

        }
        // inventory command
        public void showInventory()
        {
            this.OutputMessage("\nYour inventory contains: \n" + inventory.Description);
        }

        //adding item to inventory
        public void addItem(IItem item)
        {
            inventory.add(item);
        }

        //removing item from inventory
        public IItem removeItem(string itemName)
        {
            return inventory.remove(itemName);
        }

        //// picking up an item and adding it to inventory
        //public void pickup(string itemName)
        //{
        //    IItem item = _currentRoom.remove(itemName);
        //    if(item != null)
        //    {
        //        // could make switch statement
        //        // these items cannot be added to inventory
        //        if (itemName == "fridge" || itemName == "box" || itemName == "window")
        //        {
        //            OutputMessage("That cannot be added to your inventory.");
        //            _currentRoom.place(item);
        //        }
        //        else if(itemName == "doorKey")
        //        {
        //            addItem(item);
        //            OutputMessage("\nYou added " + itemName + " to your inventory.");
        //            Notification notification;
        //            notification = new Notification("PlayerFoundKey", this);
        //            NotificationCenter.Instance.PostNotification(notification);
        //        }
        //        else if(itemName == "confession")
        //        {
        //            addItem(item);
        //            OutputMessage("\nYou added " + itemName + " to your inventory.");
        //            Notification notification;
        //            notification = new Notification("PlayerWins", this);
        //            NotificationCenter.Instance.PostNotification(notification);
        //        }
        //        else
        //        {
        //            addItem(item);
        //            this.OutputMessage("\nYou added " + itemName + " to your inventory.");
        //        }

        //    }
        //    else
        //    {
        //        this.OutputMessage("I can't seem to find that item in this room.");
        //    }

        //}

        // picking up an item and adding it to inventory
        // more efficient with canPickup bool
        // if statements for notifications
        public void pickup(string itemName)
        {
            IItem item = _currentRoom.remove(itemName);
            if (item != null)
            {
                // could make switch statement
                // these items cannot be added to inventory
                if (item.canPickup == false)
                {
                    OutputMessage("That cannot be added to your inventory.");
                    _currentRoom.place(item);
                }
                else if (itemName == "doorKey")
                {
                    addItem(item);
                    OutputMessage("\nYou added " + itemName + " to your inventory.");
                    Notification notification;
                    notification = new Notification("PlayerFoundKey", this);
                    NotificationCenter.Instance.PostNotification(notification);
                }
                else if (itemName == "confession")
                {
                    addItem(item);
                    OutputMessage("\nYou added " + itemName + " to your inventory.");
                    Notification notification;
                    notification = new Notification("PlayerWins", this);
                    NotificationCenter.Instance.PostNotification(notification);
                }
                else
                {
                    addItem(item);
                    this.OutputMessage("\nYou added " + itemName + " to your inventory.");
                }

            }
            else
            {
                this.OutputMessage("I can't seem to find that item in this room.");
            }

        }

        // dropping an item and removing from inventory placing in current room
        public void drop(string itemName)
        {
            IItem item = removeItem(itemName);
            if (item != null)
            {
                _currentRoom.place(item);
                this.OutputMessage("\nYou dropped " + itemName + ". It is now in " + _currentRoom.Tag);
            }
            else
            {
                this.OutputMessage("I can't seem to find that item in our inventory.");
            }

        }

        // challenge task
        // player must have doorKey to unlock the locked door
        public bool hasDoorKey()
        {
            bool inventoryContains = false;
            string s = inventory.Description;
                if (s.Contains("doorKey") == true)
                {
                    inventoryContains = true;
                }
                else
                {
                    inventoryContains = false;
                }
            return inventoryContains;
        }

        // must have vaultKey to unlock vault room door
        public bool hasVaultKey()
        {
            bool inventoryContains = false;
            string s = inventory.Description;
            if(s.Contains("vaultKey") == true)
            {
                inventoryContains = true;
            }
            else
            {
                inventoryContains = false;
            }
            return inventoryContains;
        }

        // examine commmand
        // examine items to receive message about that item
        // have to figure this out about each description for specific examine
        public void Examine(string itemName)
        {
            IItem item = this._currentRoom.remove(itemName);
            if(item != null)
            {
                OutputMessage(item.Examniation);
                OutputMessage(item.Description);
                CurrentRoom.place(item);
            }
            else
            {
                this.OutputMessage("There is no item in this room.");
            }
        }

        // listen command
        // to have characters/suspects in game interact with player
        // did this exactly like the examine command
        public void Listen(string suspectName)
        {
            // each suspect has different messages
            // look for more efficient way rather than if statments
            
            ISuspects suspects = this._currentRoom.removeSuspect(suspectName);
            if(suspects != null)
            {
                OutputMessage(suspects.message);
                CurrentRoom.placeSuspect(suspects);
            }
            else
            {
                OutputMessage("I don't understand who to listen to.");
            }
        }

        // if the player has the confession item in inventory
        public bool hasConfession()
        {
            bool inventoryContains = false;
            string s = inventory.Description;
            if (s.Contains("confession") == true)
            {
                inventoryContains = true;
            }
            else
            {
                inventoryContains = false;
            }
            return inventoryContains;
        }

  

    }
}

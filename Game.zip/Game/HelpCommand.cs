﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    public class HelpCommand : Command
    {

        CommandWords words;
        public HelpCommand() : this(new CommandWords())
        {
        }

        //Help Command constructor
        public HelpCommand(CommandWords commands) : base()
        {
            words = commands;
            this.Name = "help";
        }

        override
        public bool Execute(Player player)
        {
            // if user has a word following help
            if (this.HasSecondWord())
            {
                player.OutputMessage("\nI cannot help you with " + this.SecondWord);
            }
            // prints this message to help user and give them their available commands
            else
            {
                player.OutputMessage("\nYou are the lead investigator for the Charlie Baldwin murder." + player.CurrentRoom.Description() + "\n\nYour available commands are " + words.Description());
            }
            return false;
        }
    }
}

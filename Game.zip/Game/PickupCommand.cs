﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    public class PickupCommand : Command
    {
        // Pickup Command constructor
        public PickupCommand() : base()
        {
            this.Name = "pickup";
        }

        // overriding Execute 
        override
        public bool Execute(Player player)
        {
            // which item to pick up
            if (this.HasSecondWord())
            {
                player.pickup(this.SecondWord);
            }
            else
            {
                // if player does not say what item to pickup 
                player.OutputMessage("\nPickup what?");
            }
            return false;
        }
    }
}

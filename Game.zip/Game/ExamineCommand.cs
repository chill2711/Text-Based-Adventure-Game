﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    class ExamineCommand : Command
    {
        // Examine Command constructor
        public ExamineCommand() : base()
        {
            this.Name = "examine";
        }

        // overriding Execute 
        override
        public bool Execute(Player player)
        {
            // examining this item
            if (this.HasSecondWord())
            {
                player.Examine(this.SecondWord);
            }
            else
            {
                // if player does not say what item to examine
                player.OutputMessage("\nExamine What?");
            }
            return false;
        }
    }
}

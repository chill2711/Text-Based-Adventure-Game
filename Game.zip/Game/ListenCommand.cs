﻿using System;
namespace StarterGame
{
    class ListenCommand : Command
    {
        // Listen Command constructor
        public ListenCommand() : base()
        {
            this.Name = "listen";
        }

        // overriding Execute 
        override
        public bool Execute(Player player)
        {
            // Listening to this suspect
            if (this.HasSecondWord())
            {
                player.Listen(this.SecondWord);
            }
            else
            {
                // if player does not say who to listen to 
                player.OutputMessage("\nListen to who?");
            }
            return false;
        }
    }
}

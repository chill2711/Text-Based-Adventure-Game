﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StarterGame
{
    class OpenCommand : Command
    { 
    // Open Command constructor
        public OpenCommand() : base()
    {
        this.Name = "open";
    }

    // overriding Execute 
    override
    public bool Execute(Player player)
    {
        // opening this 
        if (this.HasSecondWord())
        {
            player.Open(this.SecondWord);
        }
        else
        {
            // if player does not say what to open
            player.OutputMessage("\nOpen What?");
        }
        return false;
    }
}
}
